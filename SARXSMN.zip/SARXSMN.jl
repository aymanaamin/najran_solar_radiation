# =====================================================================
# SARX-SMN sampler (Algorithm 1)
# =====================================================================
using LinearAlgebra, Distributions, Random, Statistics, SpecialFunctions, DelimitedFiles, DataFrames


# ---------------------------------------------------------------------
abstract type SARXPrior end

struct JeffreysPrior <: SARXPrior end

struct NormalGammaPrior <: SARXPrior
    mu_phi1; mu_phi2; mu_xi
    Sig_phi1; Sig_phi2; Sig_xi
    a0::Float64
    b0::Float64
end
NormalGammaPrior(; mu_phi1 = 0.0, mu_phi2 = 0.0, mu_xi = 0.0,
                   Sig_phi1 = 1.0, Sig_phi2 = 1.0, Sig_xi = 100.0,
                   a0::Real = 1.0, b0::Real = 1.0) =
    NormalGammaPrior(mu_phi1, mu_phi2, mu_xi, Sig_phi1, Sig_phi2, Sig_xi,
                     Float64(a0), Float64(b0))

struct GPrior <: SARXPrior
    g
    beta_bar
end
GPrior(; g = nothing, beta_bar = :ols) = GPrior(g, beta_bar)


# ---------------------------------------------------------------------
function _fitSARXSMN(yt, X_exog, p, P, s, d_k, dist::Symbol;
                     ndraw::Int=25_000, nburn::Int=5_000, nthin::Int=20,
                     jitter::Real=1e-6,
                     seed::Union{Nothing,Integer}=nothing,
                     rng::Union{Nothing,AbstractRNG}=nothing,
                     clambda::Real=0.0, dlambda::Real=0.0,          
                     nu0::Real=2.0, nu1::Real=2.0,                  
                     g0::Real=2.0,  g1::Real=2.0,                   
                     tau_nu::Real=1.0, tau_gam::Real=0.3, adapt::Bool=true,
                     prior::SARXPrior=JeffreysPrior(),              
                     lambda_prior::Symbol=:joint)                   

    dist in (:N, :T, :Slash, :CN) || throw(ArgumentError("dist ∈ {:N,:T,:Slash,:CN}."))
    (p ≥ 1 && P ≥ 1 && s ≥ 1)   || throw(ArgumentError("SARX requires p, P, s ≥ 1."))
    ndraw > nburn               || throw(ArgumentError("ndraw must exceed nburn."))
    nthin ≥ 1                   || throw(ArgumentError("nthin must be ≥ 1."))
    (dist === :T || dist === :Slash) &&
        (clambda > 0 && dlambda > clambda ||
         throw(ArgumentError("SMN-t/sl require 0 < clambda < dlambda.")))
    dist === :CN && (nu0 > 0 && nu1 > 0 && g0 > 0 && g1 > 0 ||
         throw(ArgumentError("SMN-cn requires Beta hyperparameters > 0.")))

    lambda_prior in (:joint, :uniform) || throw(ArgumentError("lambda_prior ∈ {:joint,:uniform}."))
    rng = rng === nothing ? Random.GLOBAL_RNG : rng
    seed === nothing || Random.seed!(rng, seed)

    y, xy, W, n_obs, q, xyorder = build_SARX_design(yt, X_exog, p, P, s, d_k)
    xyorder == p + P*(p+1) || throw(ArgumentError("unexpected xy column layout."))
    n_obs ≥ p + P + q || @warn "n_obs < p+P+q free parameters; posterior may be improper."

    m_dim  = p + P + p*P + q                 
    k_free = p + P + q                       
    useNG  = prior isa NormalGammaPrior
    useG   = prior isa GPrior
    a_sig  = Float64(n_obs)                  
    b0     = 0.0
    gval   = 0.0

    mu1 = zeros(0); mu2 = zeros(0); muxi = zeros(0); Pm1 = zeros(0); Pm2 = zeros(0); Pmxi = zeros(0)
    Pi1 = zeros(0, 0); Pi2 = zeros(0, 0); Pixi = zeros(0, 0)
    qt1 = zeros(0); qt2 = zeros(0); qt3 = zeros(0)
    Xbar = zeros(0); zgv = zeros(0)
    if useNG
        mu1  = _as_vec(prior.mu_phi1, p);  mu2 = _as_vec(prior.mu_phi2, P);  muxi = _as_vec(prior.mu_xi, q)
        Pi1  = _as_prec(prior.Sig_phi1, p); Pi2 = _as_prec(prior.Sig_phi2, P); Pixi = _as_prec(prior.Sig_xi, q)
        Pm1  = Pi1*mu1;  Pm2 = Pi2*mu2;  Pmxi = Pixi*muxi        
        prior.a0 ≥ 0 && prior.b0 ≥ 0 || throw(ArgumentError("NG prior needs a0, b0 ≥ 0."))
        a_sig = prior.a0 + n_obs + k_free                        
        b0    = prior.b0
        qt1 = zeros(p); qt2 = zeros(P); qt3 = zeros(q)           
    elseif useG
        gval = prior.g === nothing ? 1.0/n_obs : Float64(prior.g)
        gval > 0 || throw(ArgumentError("g-prior requires g > 0."))
        Xfull = [xy W]                       
        bb = prior.beta_bar
        bbar = bb === :ols ? (cholesky(Symmetric(Xfull' * Xfull + jitter * I)) \ (Xfull' * y)) :
               (bb === nothing || bb === :zero) ? zeros(m_dim) : Vector{Float64}(bb)
        length(bbar) == m_dim || throw(ArgumentError("beta_bar must have length m = p+P+pP+q = $m_dim."))
        Xbar = Xfull * bbar                  
        a_sig = Float64(n_obs + m_dim)       
        zgv   = zeros(n_obs)                 
    end

    Y1 = @view xy[:, 1:p]
    Ys = Matrix{Float64}(undef, n_obs, P)
    @inbounds for j in 1:P; Ys[:, j] .= @view xy[:, j*(p+1)]; end
    Yx = Matrix{Float64}(undef, n_obs, p*P)
    col = 0
    @inbounds for j in 1:P, i in 1:p
        col += 1; Yx[:, col] .= @view xy[:, j*(p+1)+i]
    end

    u  = ones(n_obs)                       
    z1 = zeros(n_obs); z2 = zeros(n_obs); z3 = zeros(n_obs)
    zs = zeros(n_obs); Wxi = zeros(n_obs); Lb = zeros(n_obs)
    Aphi = zeros(n_obs); err = zeros(n_obs); m2 = zeros(n_obs)
    Z1 = zeros(n_obs, p);  Z2 = zeros(n_obs, P)
    zw1 = zeros(n_obs, p); zw2 = zeros(n_obs, P); zw3 = zeros(n_obs, q)
    K1 = zeros(p, p); K2 = zeros(P, P); K3 = zeros(q, q)
    eps1 = zeros(p); eps2 = zeros(P); eps3 = zeros(q)
    M2 = zeros(p*P, p); M1 = zeros(p*P, P); cvec = zeros(p*P)
    Ic = falses(n_obs)                     

    keep = (ndraw - nburn) ÷ nthin
    keep ≥ 1 || throw(ArgumentError("(ndraw − nburn) < nthin: nothing retained."))
    nshape = dist === :CN ? 2 : (dist === :N ? 0 : 1)
    estimates = Matrix{Float64}(undef, keep, p + P + q + 1 + nshape)
    acc = 0; accwin = 0; itwin = 0; MH_rate = NaN

    Xa = [Y1 Ys W]
    ba = cholesky(Symmetric(Xa' * Xa + jitter * I)) \ (Xa' * y)
    phi1 = Vector{Float64}(ba[1:p]); phi2 = Vector{Float64}(ba[p+1:p+P])
    _compute_Aphi!(Aphi, Y1, Ys, Yx, cvec, phi1, phi2)
    xi = (W' * W) \ (W' * (y .- Aphi))
    sigma2 = max(var(y .- Aphi .- W * xi), 1e-12)

    nu  = dist === :T ? 2.0 : dist === :Slash ? 1.0 :
          dist === :CN ? (nu0 > 1 ? (nu0 - 1)/(nu0 + nu1 - 2) : 0.5) : NaN
    gam = dist === :CN ? (g0 > 1 ? (g0 - 1)/(g0 + g1 - 2) : 0.5) : NaN
    lambda = (dist === :T || dist === :Slash) ? 0.5*(clambda + dlambda) : NaN

    for jrun in 1:ndraw
        ok = false
        mul!(Wxi, W, xi); mul!(Lb, Ys, phi2)
        @. z1 = y - Wxi - Lb
        copyto!(Z1, Y1); fill!(M2, 0.0)
        @inbounds for j in 1:P, i in 1:p; M2[(j-1)*p + i, i] = phi2[j]; end
        mul!(Z1, Yx, M2, -1.0, 1.0)
        if useG
            @. zgv = Xbar - Lb - Wxi                                  
            _gibbs_wgauss!(rng, phi1, Z1, zw1, zs, z1, u, K1, eps1, sigma2, jitter; g=gval, zg=zgv)
        elseif useNG
            _gibbs_wgauss!(rng, phi1, Z1, zw1, zs, z1, u, K1, eps1, sigma2, jitter; Pinv=Pi1, Pmu=Pm1)
        else
            _gibbs_wgauss!(rng, phi1, Z1, zw1, zs, z1, u, K1, eps1, sigma2, jitter)
        end

        mul!(Lb, Y1, phi1)
        @. z2 = y - Wxi - Lb
        copyto!(Z2, Ys); fill!(M1, 0.0)
        @inbounds for j in 1:P, i in 1:p; M1[(j-1)*p + i, j] = phi1[i]; end
        mul!(Z2, Yx, M1, -1.0, 1.0)
        if useG
            @. zgv = Xbar - Lb - Wxi                                  
            _gibbs_wgauss!(rng, phi2, Z2, zw2, zs, z2, u, K2, eps2, sigma2, jitter; g=gval, zg=zgv)
        elseif useNG
            _gibbs_wgauss!(rng, phi2, Z2, zw2, zs, z2, u, K2, eps2, sigma2, jitter; Pinv=Pi2, Pmu=Pm2)
        else
            _gibbs_wgauss!(rng, phi2, Z2, zw2, zs, z2, u, K2, eps2, sigma2, jitter)
        end

        
        _compute_Aphi!(Aphi, Y1, Ys, Yx, cvec, phi1, phi2)
        @. z3 = y - Aphi
        if useG
            @. zgv = Xbar - Aphi                                      
            _gibbs_wgauss!(rng, xi, W, zw3, zs, z3, u, K3, eps3, sigma2, jitter; g=gval, zg=zgv)
        elseif useNG
            _gibbs_wgauss!(rng, xi, W, zw3, zs, z3, u, K3, eps3, sigma2, jitter; Pinv=Pixi, Pmu=Pmxi)
        else
            _gibbs_wgauss!(rng, xi, W, zw3, zs, z3, u, K3, eps3, sigma2, jitter)
        end

        mul!(Wxi, W, xi)
        @. err = z3 - Wxi
        sse = 0.0
        @inbounds for t in 1:n_obs; sse += u[t]*err[t]*err[t]; end
        bsig = sse
        if useNG
            bsig += b0 + _qform(phi1, mu1, Pi1, qt1) + _qform(phi2, mu2, Pi2, qt2) +
                         _qform(xi, muxi, Pixi, qt3)
        elseif useG
            bsig += gval * _sq_dev(y, err, Xbar)        
        end
        sigma2 = rand(rng, InverseGamma(a_sig/2, max(bsig, 1e-12)/2))
        @. m2 = err^2 / sigma2                     

        if dist === :N
            # u ≡ 1; nothing to do
        elseif dist === :T
            @inbounds for t in 1:n_obs                        
                u[t] = rand(rng, Gamma(0.5*(nu + 1.0), inv(0.5*(m2[t] + nu))))
            end
            nu, ok = _mh_nu_t!(rng, nu, u, lambda, sum(log, u), tau_nu)
            lambda = _rand_tgamma(rng, 2.0,                            
                                  lambda_prior === :joint ? nu : max(nu - 2.0, 1e-12),
                                  clambda, dlambda)
        elseif dist === :Slash
            @inbounds for t in 1:n_obs                        
                u[t] = _rand_tgamma(rng, nu + 0.5, 0.5*m2[t], 0.0, 1.0)
            end
            nu = _rand_tgamma(rng, n_obs + 1.0, lambda - sum(log, u), 1.0, Inf)
            lambda = _rand_tgamma(rng, 2.0,                            
                                  lambda_prior === :joint ? nu : max(nu - 1.0, 1e-12),
                                  clambda, dlambda)
        else 
            logitnu = log(nu) - log1p(-nu)
            lg = 0.5*log(gam); om = 1.0 - gam
            mgam = 0
            @inbounds for t in 1:n_obs                        
                it = rand(rng) < inv(1.0 + exp(-(logitnu + lg + 0.5*om*m2[t])))
                Ic[t] = it; mgam += it
            end
            nu = rand(rng, Beta(nu0 + mgam, nu1 + n_obs - mgam))       
            Sgam = 0.0
            @inbounds for t in 1:n_obs; Ic[t] && (Sgam += err[t]*err[t]); end
            gam, ok = _mh_gamma_cn!(rng, gam, Sgam, sigma2, mgam, g0, g1, tau_gam)
            @inbounds for t in 1:n_obs; u[t] = Ic[t] ? gam : 1.0; end  
        end

        if dist === :T || dist === :CN
            if jrun <= nburn
                accwin += ok; itwin += 1
                if adapt && itwin == 100
                    accwin > 50 && (dist === :T ? (tau_nu *= 1.1) : (tau_gam *= 1.1))
                    accwin < 20 && (dist === :T ? (tau_nu *= 0.9) : (tau_gam *= 0.9))
                    accwin = 0; itwin = 0
                end
            else
                acc += ok
            end
        end

        if jrun > nburn && (jrun - nburn) % nthin == 0
            idx = (jrun - nburn) ÷ nthin
            estimates[idx, 1:p]          .= phi1
            estimates[idx, p+1:p+P]      .= phi2
            estimates[idx, p+P+1:p+P+q]  .= xi
            estimates[idx, p+P+q+1]       = sigma2
            if dist === :T || dist === :Slash
                estimates[idx, p+P+q+2]   = nu
            elseif dist === :CN
                estimates[idx, p+P+q+2]   = nu      
                estimates[idx, p+P+q+3]   = gam     
            end
        end
    end

    (dist === :T || dist === :CN) && (MH_rate = 100.0 * acc / (ndraw - nburn))
    return (estimates = estimates, MH_rate = MH_rate, n_obs = n_obs)
end

# ---------------------------------------------------------------------
fitSARXSMN_N(yt, X_exog, p, P, s, d_k; kw...) =
    _fitSARXSMN(yt, X_exog, p, P, s, d_k, :N; kw...)

fitSARXSMN_t(yt, X_exog, p, P, s, d_k; clambda::Real=0.02, dlambda::Real=0.5,
             tau_nu::Real=1.0, kw...) =
    _fitSARXSMN(yt, X_exog, p, P, s, d_k, :T; clambda=clambda, dlambda=dlambda,
                tau_nu=tau_nu, kw...)

fitSARXSMN_SL(yt, X_exog, p, P, s, d_k; clambda::Real=0.5, dlambda::Real=1.0, kw...) =
    _fitSARXSMN(yt, X_exog, p, P, s, d_k, :Slash; clambda=clambda, dlambda=dlambda, kw...)

fitSARXSMN_CN(yt, X_exog, p, P, s, d_k; nu0::Real=2.0, nu1::Real=2.0,
              g0::Real=2.0, g1::Real=2.0, tau_gam::Real=0.3, kw...) =
    _fitSARXSMN(yt, X_exog, p, P, s, d_k, :CN; nu0=nu0, nu1=nu1, g0=g0, g1=g1,
                tau_gam=tau_gam, kw...)
				
# ---------------------------------------------------------------------



function beta_bar_from_primitives(phi1::AbstractVector, phi2::AbstractVector, xi::AbstractVector)
    out = Float64[]; append!(out, phi1)
    for j in eachindex(phi2)
        push!(out, phi2[j]); append!(out, -phi1 .* phi2[j])
    end
    append!(out, xi)
    return out
end

_as_vec(x::Real, k::Int) = fill(Float64(x), k)
function _as_vec(x::AbstractVector, k::Int)
    length(x) == k || throw(ArgumentError("prior mean must have length $k (got $(length(x)))."))
    return Vector{Float64}(x)
end

function _as_prec(S::Real, k::Int)
    S > 0 || throw(ArgumentError("prior covariance factor must be positive."))
    return Matrix(Diagonal(fill(1.0 / Float64(S), k)))
end
function _as_prec(S::AbstractVector, k::Int)
    (length(S) == k && all(>(0), S)) || throw(ArgumentError("diagonal Σ must be positive, length $k."))
    return Matrix(Diagonal(1.0 ./ Vector{Float64}(S)))
end
function _as_prec(S::AbstractMatrix, k::Int)
    size(S) == (k, k) || throw(ArgumentError("Σ must be $k×$k."))
    return Matrix(Symmetric(inv(cholesky(Symmetric(Matrix{Float64}(S))))))
end

function _sq_dev(y::AbstractVector{Float64}, err::AbstractVector{Float64}, Xbar::AbstractVector{Float64})
    s = 0.0
    @inbounds for t in eachindex(y, err, Xbar)
        d = (y[t] - err[t]) - Xbar[t]
        s += d * d
    end
    return s
end

@inline function _qform(x::Vector{Float64}, mu::Vector{Float64},
                        P::Matrix{Float64}, tmp::Vector{Float64})
    k = length(x)
    @inbounds for i in 1:k; tmp[i] = x[i] - mu[i]; end
    s = 0.0
    @inbounds for j in 1:k
        tj = tmp[j]
        for i in 1:k
            s += tmp[i] * P[i, j] * tj
        end
    end
    return s
end

# ---------------------------------------------------------------------
function build_SARX_design(yt, X_exog, p, P, s, d_k)
    T = length(yt)
    r = size(X_exog, 2)

    length(d_k) == r || throw(ArgumentError("length(d_k) must equal size(X_exog, 2)."))
    all(≥(0), d_k)   || throw(ArgumentError("d_k entries must be nonnegative."))
    m_ex = isempty(d_k) ? 0 : maximum(d_k)

    
    m_ar = p + P * s
    m_ex = maximum(d_k)
    M = max(m_ar, m_ex)
    n_obs = T - M

    n_obs > 0 || throw(ArgumentError("Series too short for the requested lags."))

    
    idx_sar = Int[]
    for j in 0:P
        for i in 0:p
            if i == 0 && j == 0; continue; end
            push!(idx_sar, i + j*s)
        end
    end
    xyorder = length(idx_sar)
    
    xy = zeros(n_obs, xyorder)
    @inbounds for r_idx in 1:n_obs, c_idx in 1:xyorder
        xy[r_idx, c_idx] = yt[r_idx + M - idx_sar[c_idx]]
    end
    y = yt[M+1:end]
    
    q = 1 + sum(d_k .+ 1)
    W = zeros(n_obs, q)
    W[:, 1] .= 1.0 
    
    col = 2
    for k in 1:r
        for j in 0:d_k[k]
            W[:, col] .= X_exog[M+1-j : end-j, k]
            col += 1
        end
    end
    
    return y, xy, W, n_obs, q, xyorder
end



# ---------------------------------------------------------------------

function calculate_DIC_SARX(yt, X_exog, p, P, s, d_k, mcmc_est::AbstractMatrix, dist::String)
    y, xy, W, n_obs, q, xyorder = build_SARX_design(yt, X_exog, p, P, s, d_k)
    S = size(mcmc_est, 1)
    L_phi1 = @view xy[:, (p+1):(p+1):xyorder]          

    phi1_mean   = vec(mean(@view(mcmc_est[:, 1:p]),           dims=1))
    phi2_mean   = vec(mean(@view(mcmc_est[:, p+1:p+P]),       dims=1))
    xi_mean     = vec(mean(@view(mcmc_est[:, p+P+1:p+P+q]),   dims=1))
    sigma2_mean = mean(mcmc_est[:, p+P+q+1])
    nu_mean = nothing
    if dist in ("T", "Slash")
        nu_mean = mean(mcmc_est[:, p+P+q+2])
    elseif dist == "NormalC"
        nu_mean = [mean(mcmc_est[:, p+P+q+2]), mean(mcmc_est[:, p+P+q+3])]
    end

    function get_deviance(phi1_val, phi2_val, xi_val, sigma2_val, nu_val)
        Z_phi1 = zeros(n_obs, p)
        paramHphi = vcat(1.0, -phi2_val)
        for i in 1:p
            Z_phi1[:, i] .= @view(xy[:, i:(p+1):xyorder]) * paramHphi
        end
        err = y .- (Z_phi1 * phi1_val + L_phi1 * phi2_val) .- W * xi_val
        ll = 0.0
        if dist == "Normal"
            c = -0.5 * log(2.0 * pi * sigma2_val)
            for e in err
                ll += c - 0.5 * e^2 / sigma2_val
            end
        elseif dist == "T"
            ν = nu_val
            c = loggamma((ν + 1) / 2) - loggamma(ν / 2) - 0.5 * log(pi * ν * sigma2_val)
            for e in err
                ll += c - ((ν + 1) / 2) * log1p(e^2 / (ν * sigma2_val))
            end
        elseif dist == "Slash"
            ν = nu_val
            a     = ν + 0.5
            lognu = log(ν)
            logga = loggamma(a)
            logc0 = 0.5 * log(2.0 * pi * sigma2_val)
            for e in err
                c = 0.5 * e^2 / sigma2_val
                if c < 1e-10                     
                    ll += lognu - log(a) - logc0
                else
                    Plow, _ = gamma_inc(a, c, 0) 
                    if Plow > 0.0
                        ll += lognu + logga + log(Plow) - a * log(c) - logc0
                    else
                        ll += lognu - log(a) - logc0   
                    end
                end
            end
        elseif dist == "NormalC"
            η, γ = nu_val[1], nu_val[2]
            s1 = sqrt(sigma2_val / γ); s2 = sqrt(sigma2_val)
            c1 = η / (sqrt(2 * pi) * s1); c2 = (1 - η) / (sqrt(2 * pi) * s2)
            for e in err
                ll += log(c1 * exp(-0.5 * (e / s1)^2) + c2 * exp(-0.5 * (e / s2)^2))
            end
        else
            error("Unsupported distribution type: $dist")
        end
        return -2.0 * ll
    end

    D_bar = 0.0
    for i in 1:S
        phi1_i   = @view mcmc_est[i, 1:p]
        phi2_i   = @view mcmc_est[i, p+1:p+P]
        xi_i     = @view mcmc_est[i, p+P+1:p+P+q]
        sigma2_i = mcmc_est[i, p+P+q+1]
        nu_i = nothing
        if dist in ("T", "Slash")
            nu_i = mcmc_est[i, p+P+q+2]
        elseif dist == "NormalC"
            nu_i = @view mcmc_est[i, p+P+q+2:p+P+q+3]
        end
        D_bar += get_deviance(phi1_i, phi2_i, xi_i, sigma2_i, nu_i)
    end
    D_bar /= S
    D_mean = get_deviance(phi1_mean, phi2_mean, xi_mean, sigma2_mean, nu_mean)
    pD  = D_bar - D_mean
    return (DIC = D_bar + pD, D_bar = D_bar, D_mean = D_mean, pD = pD)
end



# ---------------------------------------------------------------------
function _chol_precision!(K::Matrix{Float64}, zw::Matrix{Float64},
                          alpha::Float64, jitter::Float64,
                          Pinv::Union{Nothing,Matrix{Float64}} = nothing)
    k = size(K, 1)
    BLAS.syrk!('U', 'T', alpha, zw, 0.0, K)          
    if Pinv !== nothing                              
        @inbounds for j in 1:k, i in 1:j
            K[i, j] += alpha * Pinv[i, j]
        end
    end
    @inbounds for d in diagind(K); K[d] += jitter; end
    @inbounds for j in 1:k, i in (j+1):k             
        K[i, j] = K[j, i]
    end
    try
        return cholesky!(K)
    catch
        BLAS.syrk!('U', 'T', alpha, zw, 0.0, K)      
        if Pinv !== nothing                          
            @inbounds for j in 1:k, i in 1:j
                K[i, j] += alpha * Pinv[i, j]
            end
        end
        @inbounds for j in 1:k
            K[j, j] += max(1e-6 * (abs(K[j, j]) + 1.0), 10.0 * jitter)
        end
        @inbounds for j in 1:k, i in (j+1):k
            K[i, j] = K[j, i]
        end
        return cholesky!(K)
    end
end


# ---------------------------------------------------------------------
function _gibbs_wgauss!(rng::AbstractRNG, theta::Vector{Float64},
                        C::AbstractMatrix{Float64}, zw::Matrix{Float64},
                        zs::Vector{Float64}, z::Vector{Float64},
                        u::Vector{Float64}, K::Matrix{Float64},
                        eps::Vector{Float64}, sigma2::Float64, jitter::Float64;
                        Pinv::Union{Nothing,Matrix{Float64}} = nothing,
                        Pmu::Union{Nothing,Vector{Float64}}  = nothing,
                        g::Float64 = 0.0,
                        zg::Union{Nothing,Vector{Float64}}   = nothing)
    n, k = size(C)
    if g > 0.0
        zg === nothing && throw(ArgumentError("g-prior update needs the pseudo-response zg."))
        @inbounds for t in 1:n                
            st = sqrt(u[t] + g)
            for j in 1:k
                zw[t, j] = st * C[t, j]
            end
            zs[t] = (u[t] * z[t] + g * zg[t]) / st
        end
    else
        @inbounds for t in 1:n                
            st = sqrt(u[t])
            for j in 1:k
                zw[t, j] = st * C[t, j]
            end
            zs[t] = st * z[t]
        end
    end
    CH = _chol_precision!(K, zw, 1.0 / sigma2, jitter, Pinv)
    mul!(theta, zw', zs, 1.0 / sigma2, 0.0)   
    if Pmu !== nothing                        
        @inbounds for j in 1:k
            theta[j] += Pmu[j] / sigma2
        end
    end
    ldiv!(CH.L, theta)                        
    ldiv!(CH.U, theta)                        
    randn!(rng, eps)                          
    ldiv!(CH.U, eps)                          
    @inbounds for j in 1:k
        theta[j] += eps[j]
    end
    return theta
end


# ---------------------------------------------------------------------
function _compute_Aphi!(out::Vector{Float64}, Y1, Ys, Yx, cvec, phi1, phi2)
    mul!(out, Y1, phi1)
    mul!(out, Ys, phi2, 1.0, 1.0)
    p = length(phi1); P = length(phi2)
    idx = 0
    @inbounds for j in 1:P, i in 1:p
        idx += 1
        cvec[idx] = phi1[i] * phi2[j]
    end
    p * P > 0 && mul!(out, Yx, cvec, -1.0, 1.0)
    return out
end


# ---------------------------------------------------------------------
function check_Aphi(yt, X_exog, p, P, s, d_k, phi1, phi2; atol = 1e-10)
    y, xy, W, n_obs, q, xyorder = build_SARX_design(yt, X_exog, p, P, s, d_k)
    M = length(yt) - n_obs
    Y1 = xy[:, 1:p]
    Ys = hcat([xy[:, j*(p+1)] for j in 1:P]...)
    Yx = zeros(n_obs, p*P); col = 0
    for j in 1:P, i in 1:p
        col += 1; Yx[:, col] .= xy[:, j*(p+1)+i]
    end
    A1 = _compute_Aphi!(zeros(n_obs), Y1, Ys, Yx, zeros(p*P),
                        collect(float.(phi1)), collect(float.(phi2)))
    A2 = [ (sum(phi1[i] * yt[M+t-i]     for i in 1:p)
         + sum(phi2[j] * yt[M+t-j*s]   for j in 1:P)
         - sum(phi1[i]*phi2[j] * yt[M+t-i-j*s] for i in 1:p, j in 1:P))
         for t in 1:n_obs
         ]
    diff = maximum(abs.(A1 .- A2))
    diff < atol || error("Aφ mismatch: max |Δ| = $diff")
    return diff
end



# ---------------------------------------------------------------------
function _rand_tgamma(rng::AbstractRNG, a::Real, b::Real, lo::Real, hi::Real)
    (a > 0 && b > 0 && lo < hi) || throw(ArgumentError("invalid truncated-gamma parameters"))
    _endpoint() = (m = (a - 1.0)/b;
                   m <= lo ? lo : (m >= hi ? hi : 0.5*(lo + hi)))
    flo = lo > 0 ? gamma_inc(a, b*lo, 0)[1] : 0.0
    fhi = isinf(hi) ? 1.0 : min(gamma_inc(a, b*hi, 0)[1], 1.0)
    fhi <= flo && return _endpoint()
    if fhi - flo > 0.25                       
        for _ in 1:200
            x = rand(rng, Gamma(a, 1.0/b))    
            lo <= x <= hi && return x
        end
    end
    for _ in 1:100                            
        v = flo + rand(rng)*(fhi - flo)
        v = clamp(v, nextfloat(Float64(flo)), prevfloat(Float64(fhi)))
        x = max(gamma_inc_inv(a, v, 1.0 - v)/b, 1e-300)
        lo <= x <= hi && return x
    end
    return _endpoint()
end


# ---------------------------------------------------------------------
function _mh_nu_t!(rng::AbstractRNG, nu_cur::Float64, u::Vector{Float64},
                   lambda::Float64, sumlnu::Float64, tau::Float64)
    n  = length(u)
    su = sum(u)
    lk(ν) = n*(0.5ν*log(0.5ν) - loggamma(0.5ν)) - ν*(0.5su + lambda) +
            (0.5ν - 1.0)*sumlnu                       
    nu_prop = nu_cur + tau*randn(rng)
    nu_prop > 2.0 || return nu_cur, false
    lq(ν) = logerfc((2.0 - ν)/(sqrt(2.0)*tau))
    logA  = lk(nu_prop) - lk(nu_cur) + lq(nu_cur) - lq(nu_prop)   
    return log(rand(rng)) < logA ? (nu_prop, true) : (nu_cur, false)
end


# ---------------------------------------------------------------------
function _mh_gamma_cn!(rng::AbstractRNG, gam_cur::Float64, Sgam::Float64,
                       sigma2::Float64, mgam::Int, g0::Float64, g1::Float64,
                       tau::Float64)
    c1 = g0 + 0.5mgam - 1.0;  c2 = g1 - 1.0;  c3 = Sgam/(2.0*sigma2)
    lk(g) = c1*log(g) + c2*log1p(-g) - c3*g
    l_prop  = log(gam_cur) - log1p(-gam_cur) + tau*randn(rng)
    gam_prop = inv(1.0 + exp(-l_prop))
    (0.0 < gam_prop < 1.0) || return gam_cur, false
    logA = lk(gam_prop) - lk(gam_cur) +
           (log(gam_prop) + log1p(-gam_prop)) - (log(gam_cur) + log1p(-gam_cur))
    return log(rand(rng)) < logA ? (gam_prop, true) : (gam_cur, false)
end



# --------------------------------------------------------------------- 
function dSlash(y::Real, mu::Real, sigma2::Real, nu::Real)
    a = nu + 0.5
    c = (y - mu)^2 / (2.0*sigma2)
    l0 = log(nu) - 0.5*log(2.0*pi*sigma2)
    c < 1e-10 && return exp(l0 - log(a))
    Plow, _ = gamma_inc(a, c, 0)
    Plow > 0 || return exp(l0 - log(a))
    return exp(l0 + loggamma(a) + log(Plow) - a*log(c))
end
dSlash(y::AbstractArray, mu, sigma2, nu) = dSlash.(y, mu, sigma2, nu)



function dNormalC(y, mu, sigma2, nu)
    eta, gama = nu
    s1 = sqrt(sigma2 / gama)
    s2 = sqrt(sigma2)

    dist1 = Normal(mu, s1)
    dist2 = Normal(mu, s2)

    Acum = eta .* pdf.(dist1, y) .+ (1 - eta) .* pdf.(dist2, y)
    return Acum
end


function AcumSlash(y, mu, sigma2, nu)
    n = length(y)
    Acum = zeros(n)
    z = (y .- mu) ./ sqrt(sigma2)
    dist = Normal()

    Threads.@threads for i in 1:n
        integrand(u) = nu * u^(nu - 1) * cdf(dist, z[i] * sqrt(u))
        Acum[i], _ = quadgk(integrand, 0.0, 1.0)
    end

    return Acum
end



function AcumNormalC(y, mu, sigma2, nu)
    eta, gama = nu
    s1 = sqrt(sigma2 / gama)
    s2 = sqrt(sigma2)

    dist1 = Normal(mu, s1)
    dist2 = Normal(mu, s2)

    Acum = eta .* cdf.(dist1, y) .+ (1 - eta) .* cdf.(dist2, y)
    return Acum
end


function Rhat(mat::AbstractMatrix)
    n, m = size(mat)  
    
    b = mapslices(mean, mat; dims=1) |> vec
    B = sum((b .- mean(mat)).^2) * n / (m - 1)

    w = mapslices(var, mat; dims=1) |> vec
    W = mean(w)

    s2hat = ((n - 1) / n) * W + B / n
    Vhat = s2hat + B / (m * n)

    cov_wb2 = cov(w, b.^2)
    cov_wb  = cov(w, b)
    covWB = n / m * (cov_wb2 - 2 * mean(b) * cov_wb)

    varV = ((n - 1)^2 / n^2) * var(w) / m +
           ((m + 1)^2 / m^2 / n^2) * 2 * B^2 / (m - 1) +
           2 * (m - 1) * (n - 1) / (m * n^2) * covWB

    df = 2 * Vhat^2 / varV
    R = sqrt(((df + 3) * Vhat) / ((df + 1) * W))

    return R
end

function Rhat1(param::AbstractMatrix, n_iter::Int, burnin::Int, n_chains::Int, n_thin::Int)
    efect = (n_iter - burnin) ÷ n_thin
    p = size(param, 2)

    mat = reshape(param, efect, n_chains * p)

    rhat = zeros(p)

    for i in 1:p
        l1 = 2 * (i - 1) + 1
        c1 = 2 * i
        rhat[i] = Rhat(mat[:, l1:c1])
    end

    return rhat
end



# ---------------------------------------------------------------------
function simulate_SARX_SMN(rng::AbstractRNG, n::Int, p::Int, P::Int, s::Int,
                           phi1, phi2, xi, d_k, sigma2::Real, dist::Symbol, shape)
    M = max(p + P*s, maximum(d_k)); warm = 200
    T = n + M + warm; r = length(d_k)
    X = zeros(T, r)
    for k in 1:r, t in 2:T
        X[t, k] = 0.7*X[t-1, k] + randn(rng)
    end
    y = zeros(T)
    for t in (M+1):T
        a = 0.0
        for i in 1:p; a += phi1[i]*y[t-i]; end
        for j in 1:P; a += phi2[j]*y[t-j*s]; end
        for i in 1:p, j in 1:P; a -= phi1[i]*phi2[j]*y[t-i-j*s]; end
        c = xi[1]; col = 2
        for k in 1:r, l in 0:d_k[k]
            t - l >= 1 && (c += xi[col]*X[t-l, k]); col += 1
        end
        z = randn(rng)
        u = dist === :N     ? 1.0 :
            dist === :T     ? rand(rng, Gamma(shape[1]/2, 2/shape[1])) :     
            dist === :Slash ? rand(rng, Beta(shape[1], 1.0)) :                
                              (rand(rng) < shape[1] ? shape[2] : 1.0)         
        y[t] = a + c + sqrt(sigma2/u)*z
    end
    return y[warm+1:end], X[warm+1:end, :]
end
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# ============== Example: simulated data from SMN-t ==================#
# ---------------------------------------------------------------------
n=300; p=1; P=1; s=4; 
phi1=[0.4]; phi2=[0.6]; 
xi=[2.0,0.5,0.4,0.6]; d_k=[1,0];
sigma2=1.0; 
shape=(4.0,); 
rngd = Random.Xoshiro(123)
yt, X = simulate_SARX_SMN(rngd, n, p, P, s, phi1, phi2, xi, d_k, sigma2, :T, shape)
ft = fitSARXSMN_t(yt, X, p, P, s, d_k)
est = ft[:estimates] 

est_summary = Matrix{Float64}(undef, size(est)[2], 4)
for j in 1:size(est)[2]
	est_summary[j, :] = [mean(est[:,j]), std(est[:,j]), quantile(est[:,j], 0.025), quantile(est[:,j], 0.975)]
end
est_summary


est_summary_df = DataFrame(Parameter = ["phi1_$(i)" for i in 1:p] ∪
                                 ["phi2_$(j)" for j in 1:P] ∪
                                 ["xi_$(k)" for k in 1:length(xi)] ∪
                                 ["sigma2"] ∪
                                 (shape[1] > 0 ? ["nu"] : []),
                        True = vcat(phi1, phi2, xi, sigma2, (shape[1] > 0 ? [shape[1]] : [])),         
                        Mean = est_summary[:, 1], SD = est_summary[:, 2],
                        lo_95 = est_summary[:, 3], hi_95 = est_summary[:, 4])
est_summary_df

